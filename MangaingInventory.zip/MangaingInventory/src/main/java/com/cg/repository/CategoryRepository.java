package com.cg.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Integer>{

}