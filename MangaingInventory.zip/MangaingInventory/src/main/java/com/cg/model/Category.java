package com.cg.model;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
//@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "InventoryM")

@XmlRootElement
public class Category implements Serializable
{
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", length = 20)
	private int id;
	/*@Column(name = "startTime", length = 20)
	private Date startTime;
	@Column(name = "endTime", length = 20)
	private Date endTime;*/
	@Column(name = "name", length = 20)
	private String name;
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	/*public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = Date.valueOf(LocalDate.now());
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}*/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Category [id=" + id +  ", name=" + name + "]";
	}

	public Category(int id, String name) {
		super();
		this.id = id;
		//this.startTime = startTime;
		//this.endTime = endTime;
		this.name = name;
	}

	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}