package com.cg.service;
import java.util.List;

import com.cg.model.Category;
//import com.cg.model.Product;
//import com.cg.model.ProductSummary;

public interface Inventory {
	/*List<Product> displayListOfProducts();

	Product addNewProduct(Product product);

	Product editExistingProductDetails(Product product);

	void removeExistingProduct(int productId);*/

	List<Category> displayListOfCategories();

	Category addNewCategory(Category category);

	void removeExistingCategory(int categoryId);

/*	Product getProductdetails(int id);

	Product validateProduct(Product product);

	List<Product> displayListOfNotApprovedProducts();

	List<Product> displayListOfApprovedProducts();*/


}