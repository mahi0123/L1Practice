package com.cg.service;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.model.Category;
//import com.cg.model.Product;
//import com.cg.model.ProductSummary;
import com.cg.repository.CategoryRepository;
//import com.cg.repository.ProductInventoryRepository;

@Component
public class InventoryImpl implements Inventory {

	//@Autowired
	//ProductInventoryRepository productInventoryRepository;
	@Autowired
	CategoryRepository categoryRepository;

	/*@Override
	//public List<Product> displayListOfProducts() {
		//return productInventoryRepository.findAll();
		// return productInventoryRepository.displayListOfProducts();
	//}

	@Override
	public Product addNewProduct(Product product) {
		product.setStartTime(Date.valueOf(LocalDate.now()));
		product.setStatus("Not Approved");
		return productInventoryRepository.save(product);
	}

	@Override
	public Product editExistingProductDetails(Product product) {
		product.setStartTime(Date.valueOf(LocalDate.now()));
		return productInventoryRepository.save(product);
	}

	@Override
	public void removeExistingProduct(int productId) {
		productInventoryRepository.deleteById(productId);

	}*/

	@Override
	public List<Category> displayListOfCategories() {
		return categoryRepository.findAll();
	}

	/*@Override
	public Category addNewCategory(Category category) {
		category.setStartTime(Date.valueOf(LocalDate.now()));
		return categoryRepository.save(category);
	}*/

	@Override
	public void removeExistingCategory(int categoryId) {
		 categoryRepository.deleteById(categoryId);

	}

	@Override
	public Category addNewCategory(Category category) {
		// TODO Auto-generated method stub
		return categoryRepository.save(category);
	}}

	/*@Override
	public Product getProductdetails(int id) {

		return productInventoryRepository.getOne(id);
	}

	@Override
	public Product validateProduct(Product product) {
		String status = product.getStatus();
		if (status.matches("accept")) {
			product.setStatus("Approved");
			return productInventoryRepository.save(product);

		}
		else {
			productInventoryRepository.deleteById(product.getId());
			return null;
		}
	}

	@Override
	public List<Product> displayListOfNotApprovedProducts() {

		return productInventoryRepository.displayListOfNotApprovedProducts();
	}

	@Override
	public List<Product> displayListOfApprovedProducts() {
		
		return productInventoryRepository.displayListOfApprovedProducts();
	}
}*/